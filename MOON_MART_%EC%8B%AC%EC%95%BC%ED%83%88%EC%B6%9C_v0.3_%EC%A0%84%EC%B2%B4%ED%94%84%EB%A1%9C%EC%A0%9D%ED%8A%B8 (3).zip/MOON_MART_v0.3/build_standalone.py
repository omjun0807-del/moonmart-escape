"""Build a single-file offline browser game. Packages existing art and code; creates no artwork."""
from pathlib import Path
from base64 import b64encode
root=Path(__file__).resolve().parent
src=(root/'index.html').read_text(encoding='utf-8')
for sheet in ('theme-v2.css','theme-v3.css'):
    src=src.replace(f'<link rel="stylesheet" href="{sheet}">', '<style>\n'+(root/sheet).read_text(encoding='utf-8')+'\n</style>')
for asset in sorted((root/'assets').glob('*.webp')):
    src=src.replace('assets/'+asset.name,'data:image/webp;base64,'+b64encode(asset.read_bytes()).decode('ascii'))
out=root/'MOON_MART_v0.3_바로실행.html'
out.write_text(src,encoding='utf-8')
print('Created',out, round(out.stat().st_size/1024),'KiB')
