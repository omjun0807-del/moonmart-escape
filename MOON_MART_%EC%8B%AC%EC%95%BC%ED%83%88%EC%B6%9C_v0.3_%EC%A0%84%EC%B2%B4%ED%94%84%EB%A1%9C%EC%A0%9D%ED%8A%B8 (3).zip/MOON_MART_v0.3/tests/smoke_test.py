"""MOON MART EP01 Chromium synthetic tests.
Requirement: pip install playwright; Chromium executable available.
This suite uses page.set_content because browser navigation can be restricted in CI.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

HTML = Path(__file__).resolve().parents[1].joinpath('index.html').read_text(encoding='utf-8')


def action(page, key):
    page.locator(f'button[data-action="{key}"]').first.click()


def close(page):
    page.locator('#dialogClose').click()


def run():
    summary=[]
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1280,'height':900})
        page.set_default_timeout(3000)
        errors=[]
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.evaluate("""Object.defineProperty(window,'localStorage',{configurable:true,value:(()=>{
            const m=new Map();return {getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()};
        })()})""")
        page.set_content(HTML)
        assert page.locator('#dialogTitle').inner_text()=='00:13, 셔터가 내려왔다'
        assert page.locator('#saveBadge').inner_text()=='AUTO SAVE'
        page.locator('#startGame').click()
        action(page,'shelf')
        assert '건전지' in page.locator('#inventory').inner_text()
        close(page)
        action(page,'receipt')
        assert '영수증' in page.locator('#inventory').inner_text()
        close(page)
        # Persist state and recreate HTML document using the same localStorage mock.
        assert '"receipt":true' in page.evaluate('localStorage.getItem("moon_mart_escape_ep01_v1")')
        page.set_content(HTML)
        assert page.locator('#overlay').is_hidden()
        assert '영수증' in page.locator('#inventory').inner_text()
        summary.append('자동 저장과 이어하기: PASS')
        action(page,'register')
        page.locator('form[data-puzzle="register"] input').fill('000')
        page.locator('form[data-puzzle="register"] button[type="submit"]').click()
        assert '암호가 다릅니다' in page.locator('#puzzleError').inner_text()
        page.locator('form[data-puzzle="register"] input').fill('427')
        page.locator('form[data-puzzle="register"] button[type="submit"]').click()
        assert '창고 열쇠' in page.locator('#inventory').inner_text()
        page.locator('[data-goto="storage"]').click()
        assert page.locator('#roomTitle').inner_text()=='창고'
        action(page,'breaker')
        page.locator('[data-switch="보안"]').click()
        assert '초기화' in page.locator('#puzzleError').inner_text()
        for s in ['냉장','조명','보안']:
            page.locator(f'[data-switch="{s}"]').click()
        assert 'POWER RESTORED' in page.locator('#dialogBody').inner_text()
        close(page)
        action(page,'scanner')
        assert 'BLUE' in page.locator('#dialogBody').inner_text()
        close(page)
        action(page,'toolbox')
        page.locator('form[data-puzzle="toolbox"] input').fill('385')
        page.locator('form[data-puzzle="toolbox"] button[type="submit"]').click()
        assert '관리실 카드' in page.locator('#inventory').inner_text()
        page.locator('[data-goto="office"]').click()
        assert page.locator('#roomTitle').inner_text()=='관리실'
        action(page,'terminal')
        page.locator('#verifySymbols').click()
        assert '잘못' in page.locator('#puzzleError').inner_text()
        for i, count in enumerate((1,2,3)):
            for _ in range(count):
                page.locator(f'[data-symbol="{i}"]').click()
        page.locator('#verifySymbols').click()
        assert 'UNLOCKED' in page.locator('#dialogBody').inner_text()
        page.locator('[data-goto="shop"]').click()
        action(page,'frontDoor')
        assert '탈출 성공' in page.locator('#dialogBody').inner_text()
        assert page.locator('#progressLabel').inner_text()=='100% 완료'
        assert not errors, errors
        summary.append('전체 퍼즐·실패 처리·탈출 엔딩: PASS (JS 오류 0개)')
        page.locator('[data-reset-confirm]').click()
        assert page.locator('#dialogTitle').inner_text()=='00:13, 셔터가 내려왔다'
        assert page.evaluate('window.__moonMartTest.state().inventory.length')==0
        summary.append('새 게임 초기화: PASS')
        mobile=browser.new_page(viewport={'width':390,'height':844}, is_mobile=True, has_touch=True)
        mobile_errors=[]
        mobile.on('pageerror',lambda e:mobile_errors.append(str(e)))
        mobile.set_content(HTML)
        mobile.locator('#startGame').tap()
        assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        assert mobile.locator('#objectGrid button').count()==6
        mobile.locator('button[data-action="shelf"]').last.tap()
        assert '건전지' in mobile.locator('#inventory').inner_text()
        assert not mobile_errors, mobile_errors
        summary.append('390px 터치 화면·가로 넘침·장면 탐색: PASS')
        browser.close()
    for s in summary:print(s)


if __name__=='__main__':run()
