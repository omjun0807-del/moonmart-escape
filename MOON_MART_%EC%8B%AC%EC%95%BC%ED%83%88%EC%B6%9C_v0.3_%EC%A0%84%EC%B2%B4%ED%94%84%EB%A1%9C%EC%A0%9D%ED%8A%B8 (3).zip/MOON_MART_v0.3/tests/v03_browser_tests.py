"""In-memory real CSS/assets Chromium tests; navigation blocked by environment policy."""
from pathlib import Path
from playwright.sync_api import sync_playwright
HTML=Path(__file__).resolve().parents[1].joinpath('MOON_MART_v0.3_바로실행.html').read_text(encoding='utf-8')
JS_MEMORY="""Object.defineProperty(window,'localStorage',{configurable:true,value:(()=>{const m=new Map();return {getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}})()})"""
def action(page,key):
    page.locator(f'#objectGrid button[data-action="{key}"]').click()
def go(page,name):
    page.locator(f'#roomNav [data-room="{name}"]').click()
def run():
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width,height,mobile in [(1440,900,False),(390,844,True),(320,700,True)]:
   page=browser.new_page(viewport={'width':width,'height':height},is_mobile=mobile,has_touch=mobile)
   page.set_default_timeout(4800);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.evaluate(JS_MEMORY)
   page.set_content(HTML)
   assert page.locator('#startGame').is_visible()
   assert page.locator('#saveBadge').text_content().strip()=='AUTO SAVE'
   page.locator('#startGame').click()
   assert page.locator('#sceneArt img').evaluate('(x)=>x.complete && x.naturalWidth>=1500')
   assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
   if mobile:
    assert page.locator('#panRight').is_visible()
    before=page.locator('#sceneCamera').evaluate('x=>getComputedStyle(x).transform')
    page.locator('#panRight').click()
    page.wait_for_timeout(460)
    after=page.locator('#sceneCamera').evaluate('x=>getComputedStyle(x).transform')
    assert before!=after,(before,after)
    page.locator('#panLeft').click()
    page.locator('#mobileHint').click()
    assert '힌트' in page.locator('#dialogTitle').inner_text()
    page.locator('#dialogClose').click()
   action(page,'shelf');assert '건전지' in page.locator('#inventory').inner_text();page.locator('#dialogClose').click()
   action(page,'receipt');assert page.locator('.scene-detail').count()==1
   assert '영수증' in page.locator('#inventory').inner_text();page.locator('#dialogClose').click()
   # Test persistence after full render in same browser storage.
   page.set_content(HTML)
   assert page.locator('#overlay').is_hidden()
   assert '영수증' in page.locator('#inventory').inner_text()
   action(page,'register')
   assert page.locator('.evidence-art').count()>=1
   page.locator('[data-puzzle="register"] input').fill('000')
   page.locator('[data-puzzle="register"] button[type="submit"]').click()
   assert '암호가 다릅니다' in page.locator('#puzzleError').inner_text()
   page.locator('[data-puzzle="register"] input').fill('427')
   page.locator('[data-puzzle="register"] button[type="submit"]').click()
   assert '창고 열쇠' in page.locator('#inventory').inner_text()
   page.locator('[data-goto="storage"]').click()
   assert page.locator('#roomTitle').inner_text()=='창고'
   action(page,'breaker');page.locator('[data-switch="보안"]').click()
   assert '초기화' in page.locator('#puzzleError').inner_text()
   for switch in ['냉장','조명','보안']:page.locator(f'[data-switch="{switch}"]').click()
   assert 'POWER RESTORED' in page.locator('#dialogBody').inner_text()
   page.locator('#dialogClose').click()
   action(page,'scanner');assert 'BLUE' in page.locator('#dialogBody').inner_text();page.locator('#dialogClose').click()
   action(page,'toolbox')
   page.locator('[data-puzzle="toolbox"] input').fill('385')
   page.locator('[data-puzzle="toolbox"] button[type="submit"]').click()
   page.locator('[data-goto="office"]').click()
   assert page.locator('#roomTitle').inner_text()=='관리실'
   action(page,'terminal')
   for i,count in enumerate((1,2,3)):
    for _ in range(count):page.locator(f'[data-symbol="{i}"]').click()
   page.locator('#verifySymbols').click()
   assert 'UNLOCKED' in page.locator('#dialogBody').inner_text()
   page.locator('[data-goto="shop"]').click()
   action(page,'frontDoor')
   assert '탈출 성공' in page.locator('#dialogBody').inner_text()
   assert '100% 완료' in page.locator('#progressLabel').inner_text()
   page.locator('[data-reset-confirm]').click()
   assert page.locator('#startGame').is_visible()
   assert not errors,errors
   print(f'PASS {width}px full route, save, touch/pan, no JS errors')
   page.close()
  browser.close()
if __name__=='__main__':run()
